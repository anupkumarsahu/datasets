# detection > 2024-06-05 6:13pm
https://universe.roboflow.com/aiml-ewqb8/detection-c8jjo

Provided by a Roboflow user
License: MIT

